#!/bin/bash
java -DNOSECURITY=true -jar Grp1.jar
