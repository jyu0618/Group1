#!/bin/bash
java -DNOSECURITY=true -jar Group1.jar
